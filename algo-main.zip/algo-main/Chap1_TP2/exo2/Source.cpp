#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include <time.h>

int main(int argc, char** argv)
{
	int a;
	int b;
	int c;
	printf("Entrez le premier nombre entier : ");
	scanf("%d", &a);
	printf_s("Entrez le second nombre entier : ");
	scanf("%d", &b);
	printf_s("Entrez le troisieme nombre entier : ");
	scanf("%d", &c);

	if (a>b)
	printf("Le resultat de a,b et c dans l'ordre croissant est : %d \n", resultat);
	_getch();
}